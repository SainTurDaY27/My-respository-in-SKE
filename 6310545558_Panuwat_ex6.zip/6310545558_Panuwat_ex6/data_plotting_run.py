import data_processing as dp
import matplotlib.pyplot as plt

# Scatter plot of cities showing latitudes versus temperatures
x = []
y = []
for city in dp.cities_data:
    x.append(float(city['latitude']))
    y.append(float(city['temperature']))
plt.xlabel('latitude')
plt.ylabel('temperature')
plt.scatter(x, y)
plt.show()

# Bar chart showing average temperatures of all cities in each country
bars = []  # list of countries
temperature = []  # average temperature of each country
dict = dp.average_country_temp(dp.cities_data)
for key, value in dict.items():
    bars.append(key)
    temperature.append(value)

numbars = len(bars)
width = .75
plt.bar(range(numbars), temperature, width, align='center')
plt.xlabel('country')
plt.ylabel('temperature')
plt.xticks(range(numbars), bars, rotation='vertical')
print(bars)
print(temperature)
plt.show()

# Pie chart showing number of EU countries versus non-EU countries
numEU = 0
numNotEU = 0
for country in dp.countries_data:
    if country['EU'] == 'yes':
        numEU += 1
    else:
        numNotEU += 1
plt.pie([numEU, numNotEU], labels=['EU', 'not EU'], autopct='%1.1f%%')
plt.show()

# Bar chart showing population of countries that are in EU but do not have coastline
city, population = [], []
data = dp.population_countries_no_coastline_in_EU(dp.countries_data)
for i in data:
    city.append(i)
    population.append(float(data[i]))
plt.bar(city, population)
plt.xticks(rotation="vertical")
plt.xlabel("Country")
plt.ylabel("Population")
plt.show()

# Pie chart showing number of EU cities versus non-EU cities

# your code here
all_city = dp.cities_in_EU(dp.cities_data, dp.countries_data)
city_in_EU = 0
city_not_in_EU = 0
for city in all_city:
    if all_city[city] == "yes":
        city_in_EU += 1
    elif all_city[city] == "no":
        city_not_in_EU += 1
plt.pie([city_in_EU, city_not_in_EU], labels=["EU", "not in EU"], autopct="%1.1f%%")
plt.show()

# Scatter plot of players showing minutes played versus passes made;
# color each player based on their position (goalkeeper, defender, midfielder, forward)

# your code here
minute_list, passes_list, color_list = [], [], []
for player in dp.players_data:
    minute_list.append(float(player["minutes"]))
    passes_list.append(float(player["passes"]))
    if player["position"] == "defender":
        color_list.append("red")
    elif player["position"] == "midfielder":
        color_list.append("pink")
    elif player["position"] == "forward":
        color_list.append("purple")
    elif player["position"] == "goalkeeper":
        color_list.append("blue")
plt.scatter(minute_list, passes_list, c=color_list)
plt.xlabel("Minutes")
plt.ylabel("Passes")
plt.show()


# Bar chart showing average number of passes made by each player position (defender, midfielder, forward, goalkeeper)

# your code here
pass_averages = dp.average_passes(dp.players_data)
position_list = ["defenders", "midfielders", "forwards", "goalkeepers"]
plt.bar(position_list, pass_averages, width=.75)
plt.xticks(rotation="vertical")
plt.show()


# Bar chart showing the survival rate in each passenger class; the three bars should be labeled 'first', 'second', 'third'.

# your code here
rate_list = []
passenger_class = ["1", "2", "3"]
class_list = ["first", "second", "third"]
for i in passenger_class:
    rate_list.append(dp.class_survival_rate(i, dp.titanic_data))

plt.bar(class_list, rate_list)
plt.xticks(rotation='vertical')
plt.show()

# Pie chart showing the number of male survivors versus female survivors

# your code here
survivors = [dp.gender_survival_number("M", dp.titanic_data), dp.gender_survival_number("F", dp.titanic_data)]
plt.pie(survivors, labels=["Male", "Female"], autopct="%1.1f%%")
plt.show()
