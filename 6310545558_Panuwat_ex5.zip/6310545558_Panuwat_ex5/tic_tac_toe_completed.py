import sys
theBoard = {'1': ' ', '2': ' ', '3': ' ', '4': ' ', '5': ' ', '6': ' ', '7': ' ', '8': ' ', '9': ' '}
test_list = []
def printBoard(board):
    # print main board
    print('1' + '|' + '2' + '|' + '3')
    print('-+-+-')
    print('4' + '|' + '5' + '|' + '6')
    print('-+-+-')
    print('7' + '|' + '8' + '|' + '9')
    print(" ")
    # print true board
    print(board['1'] + '|' + board['2'] + '|' + board['3'])
    print('-+-+-')
    print(board['4'] + '|' + board['5'] + '|' + board['6'])
    print('-+-+-')
    print(board['7'] + '|' + board['8'] + '|' + board['9'])


def input_board():
    for i in range(9):
        printBoard(theBoard)
        if turn == 'X':
            turn = 'O'
        else:
            turn = 'X'
        move = print('Turn for ' + turn + '. Move on which space?')
        move = input()
        move.append(test_list)
        theBoard[move] = turn
        conclusion()
    return move, turn


def conclusion():
    if (theBoard['1'] == "X" and theBoard['2'] == "X" and theBoard['3'] == "X") or (theBoard['4'] == "X" and theBoard['5'] == "X" and theBoard['6'] == "X") or (theBoard['7'] == "X" and theBoard['8'] == "X" and theBoard['9'] == "X") or (theBoard['1'] == "X" and theBoard['5'] == "X" and theBoard['9'] == "X") or (theBoard['3'] == "X" and theBoard['5'] == "X" and theBoard['7'] == "X") or (theBoard['4'] == "X" and theBoard['1'] == "X" and theBoard['7'] == "X") or (theBoard['2'] == "X" and theBoard['5'] == "X" and theBoard['8'] == "X") or (theBoard['3'] == "X" and theBoard['9'] == "X" and theBoard['6'] == "X"):
       printBoard(theBoard)
       print("X wins")
       sys.exit()
    elif (theBoard['1'] == "O" and theBoard['2'] == "O" and theBoard['3'] == "O") or (theBoard['4'] == "O" and theBoard['5'] == "O" and theBoard['6'] == "O") or (theBoard['7'] == "O" and theBoard['8'] == "O" and theBoard['9'] == "O") or (theBoard['1'] == "O" and theBoard['5'] == "O" and theBoard['9'] == "O") or (theBoard['3'] == "O" and theBoard['5'] == "O" and theBoard['7'] == "O") or (theBoard['4'] == "O" and theBoard['1'] == "O" and theBoard['7'] == "O") or (theBoard['2'] == "O" and theBoard['5'] == "O" and theBoard['8'] == "O") or (theBoard['3'] == "O" and theBoard['9'] == "O" and theBoard['6'] == "O"):
        printBoard(theBoard)
        print("O wins")
        sys.exit()
    else:
        pass
# main_part
turn = 'X'
for i in range(9):
    printBoard(theBoard)
    move = input('Input a number 1 to 9 to place ' + turn + ' in one of nine square: ')
    if theBoard[move] == " ":
        theBoard[move] = turn
    else:
        move = input('Input a number 1 to 9 to place ' + turn + ' in one of nine square: ')
        if theBoard[move] == " ":
            theBoard[move] = turn
        else:
            pass
    conclusion()
    if theBoard['1'] != " " and theBoard['2'] != " " and theBoard['3'] != " " and theBoard['4'] != " " and theBoard['5'] != " " and theBoard['6'] != " " and theBoard['7'] != " " and theBoard['8'] != " " and theBoard['9'] != " " :
        printBoard(theBoard)
        print("Both tie.")
        sys.exit()
# change turn
    if turn == 'X':
        turn = 'O'
    else:
        turn = 'X'
printBoard(theBoard)
