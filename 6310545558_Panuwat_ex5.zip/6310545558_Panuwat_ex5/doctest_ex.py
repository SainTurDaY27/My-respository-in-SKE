# 1.1
def string_interleave(str1, str2):
    """
    start with the first character from the larger of the two strings s1 and s2, take each character from the
smaller string from index 0 on and interleave it with each character from the larger string. Return the new
interleaved string.

    Args :
        str1, str2 (string) : input two string

    Returns :
        (string) : sum of both string in condition

    Raises :
        TypeError: If str1 or str2 is not a string

    Examples:
    >>> string_interleave("abc","mnopq")
    'manbocpq'
    >>> string_interleave("mnopq","abc")
    'manbocpq'
    >>> string_interleave("Hello","Sawasdee Thailand")
    'SHaewlalsodee Thailand'
    >>> string_interleave("Mine","Thai")
    'TMhianie'
    >>> string_interleave("Python","easy")
    'Peyatshyon'
    >>> string_interleave("abc",123)
    Traceback (most recent call last):
        ...
    TypeError: Input is not a string

    """

    if isinstance(str1, str) or isinstance(str2, str) == False:
        raise TypeError("Input is not a string")

    if len(str1) > len(str2):
        final_str.append(str1[0])
        for i in range(len(str1)):
            if i < len(str2):
                final_str.append(str2[i])
            if i + 1 < len(str1):
                final_str.append(str1[i + 1])
    elif len(str1) < len(str2):
        final_str.append(str2[0])
        for i in range(len(str2)):
            if i < len(str1):
                final_str.append(str1[i])
            if i + 1 < len(str2):
                final_str.append(str2[i + 1])
    else:
        for i in range(len(str1)):
            final_str.append(str2[i])
            final_str.append(str1[i])

        # put in ans_str
    for i in range(len(final_str)):
        ans_str += final_str[i]
    return ans_str

# 1.2
def selective_sum(n, k):
    """
     Returns the sum of the k largest digits of n

    Args :
        n (int) : input integer
        k (int) : input integer >= 0

    Returns :
        (int) : The sum of the k largest digits of n

    Raises :
        TypeError: if n or k is not integer
        ValueError: if k is negative

    Examples :
    >>> selective_sum(3018, 2)
    11
    >>> selective_sum(593796, 3)
    25
    >>> selective_sum(12345, 10)
    15
    >>> selective_sum(123456789, 4)
    30
    >>> selective_sum(3018, "Hello World")
    Traceback (most recent call last):
        ...
    TypeError: Input is not an integer
    >>> selective_sum(12345, -10)
    Traceback (most recent call last):
        ...
    ValueError: k is negative

    """

    if isinstance(n, int) or isinstance(k, int) == False:
        raise TypeError("Input is not an integer")
    if k < 0:
        raise ValueError("k is negative")


    list_num = list(str(n))
    final_list = []
    if len(list_num) > k:
        list_num = sorted(list_num, reverse=True)
        for i in range(k):
            final_list.append(int(list_num[i]))
    else:
        for i in range(len(list_num)):
            final_list.append(int(list_num[i]))
    return sum(final_list)


# 1.3
def list_intersect(list1, list2):
    """
     given list1 and list2 are lists, returns the intersection list of list1 and list2. The intersection list contains elements
that are in both list1 and contains no duplicate elements.

    Args :
        list1, list2 (list) : input two list

    Returns :
        (list) : the intersection list of list1 and list2

    Raises :
        TypeError : if list1 or list2 is not list

    Examples :
    >>> list_intersect([1, 2, 1, 3, 4], [1, 2, 2, 3, 4])
    [1,2,3,4]
    >>> list_intersect([1, 2, 3, 4], [1, 2, 3, 4, 5, 6, 7, 8])
    [1,2,3,4]
    >>> list_intersect([9, 10, 11, 12], [5, 6, 7, 8])
    []
    >>> list_intersect([9, 10, 11, 12], [5, 6, 9, 10, 7, 8])
    [9, 10]
    >>> list_intersect([1, 2, 3, 4], "Hello World!")
    Traceback (most recent call last):
        ...
    TypeError: Input is not a list
    """
    if isinstance(list1, list) or isinstance(list2, list) == False:
        raise TypeError("Input is not a list")


    return list(set(list1) & set(list2))


