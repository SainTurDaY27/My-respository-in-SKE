# 1_Particles

first_input = input("Spin: ")
second_input = input("Charge: ")
particle_type = str()
class_type = str()
if first_input == "1/2":
    if second_input == "-1/3":
        particle_type = "Strange"
        class_type = "Quark"
    elif second_input == "2/3":
        particle_type = "Charm"
        class_type = "Quark"
    elif second_input == "-1":
        particle_type = "Electron"
        class_type = "Lepton"
    elif second_input == "0":
        particle_type = "Neutrino"
        class_type = "Lepton"
elif first_input == "1":
    particle_type = "Photon"
    class_type = "Boson"
print(f"{particle_type} {class_type}")

# 2_Calculator

first_num = float(input("First number: "))
second_num = float(input("Second number: "))
op_input = input("Operation: ")
if second_num == 0:
    print("Division by 0!")
else:
    if op_input == "+":
        total_num = first_num + second_num
        print(total_num)
    elif op_input == "-":
        total_num = first_num - second_num
        print(total_num)
    elif op_input == "/":
        total_num = first_num / second_num
        print(total_num)
    elif op_input == "*":
        total_num = first_num * second_num
        print(total_num)
    elif op_input == "mod":
        total_num = first_num % second_num
        print(total_num)
    elif op_input == "div":
        total_num = first_num // second_num
        print(total_num)

# 3_Farm

money = int(input("Your money: "))
animal = str()
total = int()
if money >= 6769:
    total = money // 6769
    animal = "sheep"
    if total >= 2:
        print(f"{total} {animal}s")
    elif total == 1:
        print(f"{total} {animal}")
elif money >= 3848:
    total = money // 3848
    animal = "cow"
    if total >= 2:
        print(f"{total} {animal}s")
    else:
        print(f"{total} {animal}")
elif money >= 1296:
    total = money // 1296
    animal = "pig"
    if total >= 2:
        print(f"{total} {animal}s")
    else:
        print(f"{total} {animal}")
elif money >= 678:
    total = money // 678
    animal = "goat"
    if total >= 2:
        print(f"{total} {animal}s")
    else:
        print(f"{total} {animal}")
elif money >= 23:
    total = money // 23
    animal = "chicken"
    if total >= 2:
        print(f"{total} {animal}s")
    else:
        print(f"{total} {animal}")
else:
    print("None")

# 4_Day

time_change = int(input("Offset: "))
hour_change = time_change + 10.5
if hour_change > 24:
    print("Wednesday")
elif hour_change < 0:
    print("Monday")
else:
    print("Tuesday")

# 5_even_odd

def is_even(number):
    number = int(input("Your Number: "))
    if number % 2 == 0:
        return "True"
    else:
        return "False"


is_even(5)

# 6_Leap_year

def is_leap_year(year):
    if year % 4 == 0:
        if year % 100 == 0:
            if year % 400 == 0:
                return "True"
            else:
               return "False"
        else:
            return "True"
    else:
        return "False"


is_leap_year(1700)
is_leap_year(1600)
is_leap_year(2024)

# 7_interval_intersect

def interval_intersection(a,b,c,d):
    if a <= c and b <= d:
        return "True"
    else:
        return "False"


interval_intersection(2,3,4,5)

# 8_print_digits

def print_digits():
    input_num = int(input("Your number: "))
    if input_num > 100 or input_num <= 0:
        print("Error: Input is not a two digit number.")
    else:
        digit_num = input_num // 10
        min_num = input_num - (digit_num*10)
        print(f"The tens digit is {digit_num} and the ones digits is {min_num}")


print_digits()

# 9_quadratic_equation

def smaller_root():
    a = float(input("Input a: "))
    b = float(input("Input b: "))
    c = float(input("Input c: "))
    calculate = (b**2)-(4*a*c)
    positive_calculate = (-1*b) + ((b ** 2) - (4 * a * c))**2 / (2 * a)
    negative_calculate = (-1*b) - ((b ** 2) - (4 * a * c))**2 / (2 * a)
    if calculate < 0:
        print("Error: No real solutions")
    else :
        if positive_calculate >= negative_calculate:
            return positive_calculate
        else:
            return negative_calculate


smaller_root()

# 10_there_is_odd

def there_is_odd():
    x = int(input("Input X: "))
    y = int(input("Input Y: "))
    z = int(input("Input Z: "))
    x_odd = x % 2
    y_odd = y % 2
    z_odd = z % 2
    if x_odd == 1 :
        if y_odd == 1:
            if z_odd == 1:
                print(f"There is an odd number whose value is {x},{y},{z}")
            else:
                print(f"There is an odd number whose value is {x},{y}")
        else:
            print(f"There is an odd number whose value is {x}")
    else:
        if y_odd == 1:
            if z_odd == 1:
                print(f"There is an odd number whose value is {y},{z}")
            else:
                print(f"There is an odd number whose value is {y}")
        else:
            if z_odd ==1:
                print(f"There is an odd number whose value is {z}")
            else:
                print(f"There is no odd number")


there_is_odd()

# 11_list_all_odds

def list_all_odds():
    w = int(input("Input W: "))
    if w % 2 == 1:
        print(f"This value is odd {w}")
    x = int(input("Input X: "))
    if x % 2 == 1:
        print(f"This value is odd {x} ")
    y = int(input("Input Y: "))
    if y % 2 == 1:
        print(f"This value is odd {y} ")
    z = int(input("Input Z: "))
    if z % 2 == 1:
        print(f"This value is odd {z} ")
    if w % 2 == 0 and x % 2 == 0 and y % 2 == 0 and z % 2 == 0:
        print("There is no odd number")


list_all_odds()

# 12_max_of_three

def max_of_three():
    x = int(input("Input X: "))
    y = int(input("Input Y: "))
    z = int(input("Input Z: "))
    if x > y and x > z:
        print(f"The max value is {x} ")
    if y > x and y > z:
        print(f"The max value is {y} ")
    if z > x and z > y:
        print(f"The max value is {z} ")


max_of_three()

        

        