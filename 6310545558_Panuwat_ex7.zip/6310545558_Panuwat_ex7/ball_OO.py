import turtle
import random


class Ball:
    def __init__(self, canvas_width, canvas_height, ball_radius):
        self.__xpos = random.randint(-1*canvas_width + ball_radius, canvas_width - ball_radius)
        self.__ypos = random.randint(-1*canvas_height + ball_radius, canvas_height - ball_radius)
        self.__vx = random.randint(1, 0.025*canvas_width)
        self.__vy = random.randint(1, 0.025*canvas_width)
        self.__ball_color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        self.__canvas_width = canvas_width
        self.__canvas_height = canvas_height
        self.__ball_radius = ball_radius

    def draw_circle(self):
        # draw a circle of radius equals to size at x, y coordinates and paint it with color
        turtle.penup()
        turtle.color(self.__ball_color)
        turtle.fillcolor(self.__ball_color)
        turtle.goto(self.__xpos, self.__ypos)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(self.__ball_radius)
        turtle.end_fill()

    def move_circle(self):
        # update the x, y coordinates of ball i with velocity in the x (vx) and y (vy) components
        self.__xpos += self.__vx
        self.__ypos += self.__vy

        # if the ball hits the side walls, reverse the vx velocity
        if abs(self.__xpos + self.__vx) > (self.__canvas_width - self.__ball_radius):
            self.__vx = -self.__vx

        # if the ball hits the ceiling or the floor, reverse the vy velocity
        if abs(self.__ypos + self.__vy) > (self.__canvas_height - self.__ball_radius):
            self.__vy = -self.__vy

