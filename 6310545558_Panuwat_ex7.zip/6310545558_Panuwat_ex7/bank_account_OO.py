import random


class Operation:
    def __init__(self, name):
        self.account_id = str(random.randint(1000, 9999))
        self.account_name = f"account{name}"
        self.balance = random.randint(20, 2000)

    def __str__(self):
        return self.all_account


class Database:
    def __init__(self):
        self.all_account = {}

    def add(self, account):
        self.all_account[account.account_id] = [account.account_name, account.balance]

    def search(self, number):
        try:
            print(f"{number} : {self.all_account[number]}")
        except:
            print("Record not found.")

    def deposit(self, account, amount):
        try:
            self.all_account[account][1] += amount
        except:
            print("Record not found.")

    def withdraw(self, account, amount):
        try:
            self.all_account[account][1] -= amount
        except:
            if account not in self.all_account.keys():
                print("Record not found.")
            elif self.all_account[account][1] < amount:
                print("Insufficient funds. Transaction aborted.")

    def __str__(self):
        return "\n".join([i + ":" + str(self.all_account[i]) for i in self.all_account])


all_account = Database()
for i in range(10):
    all_account.add(Operation(i))

# main loop to run our banking system
while True:
    print('Banking System Menu:')
    print('Press 1 to display all records.')
    print('Press 2 to search for a record')
    print('Press 3 to deposit amount')
    print('Press 4 to withdraw amount')
    print('Press 0 to exit')
    choice = input('Enter a choice (0-4): ')
    if choice == '0':
        break
    elif choice == '1':
        print(all_account)
    elif choice == "2":
        number_to_search = input("Enter an account number to search: ")
        all_account.search(number_to_search)
    elif choice == "3":
        deposit_account = input('Enter an account number to deposit: ')
        deposit_amount = float(input('Enter an amount to deposit: '))
        all_account.deposit(deposit_account, deposit_amount)
    elif choice == '4':
        withdraw_account = input('Enter an account number to withdraw: ')
        withdraw_amount = float(input('Enter an amount to withdraw: '))
        all_account.withdraw(withdraw_account, withdraw_amount)
    else:
        print('Invalid choice selection. Please try again')
