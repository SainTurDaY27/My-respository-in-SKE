from mastermind import *

new_game = MasterMindBoard()
while True:
    input_guess = input("What is your guess?: ")
    print('Your guess is', input_guess)
    MasterMindBoard.guess(input_guess)
    MasterMindBoard.display_clue()
    if MasterMindBoard.done():
        break
