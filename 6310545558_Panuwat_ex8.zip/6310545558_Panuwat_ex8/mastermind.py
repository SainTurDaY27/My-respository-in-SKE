class MasterMindBoard:

    def __init__(self):
        """Preparing the variable that keep the data to manage for the output of this Mastermind game
        # >>> a = MasterMindBoard()
        # >>> print(a)
        <mastermind.MasterMindBoard object at 0x016CF658>
        """
        sol_str = ''
        for i in range(4):
            import random
            sol_str += str(random.randint(1, 6))
        self.solution = sol_str
        self.num_guesses = 0
        self.guess_input = ''
        self.clue = ''

    def guess(self, input_guess):
        """Operation about self.guess_input to collect the value from user input(input_guess)
        # >>> a = MasterMindBoard()
        # >>> test = 1234
        # >>> a.guess(test)
        # ['1', '2', '3', '4']
        """
        self.guess_input = ""
        for i in range(len(input_guess)):
            self.guess_input += input_guess[i]

    def display_clue(self):
        """Display a hint for mastermind answer to help player to find an answer
        # >>> a = MasterMindBoard()
        # >>> test = 1234
        # >>> a.guess(test)
        # >>> a.display_clue()
        # "****"
        """
        self.clue = ''
        for i in range(4):
            if self.guess_input[i] == self.solution[i]:
                self.clue += "*"
            elif self.guess_input[i] in self.solution:
                self.clue += "o"
            else:
                self.clue += "_"
        self.num_guesses += 1
        print(self.clue)

    def done(self):
        """The method that if player have finish the game, it will return the number of rounds that player have play.
        # >>> a = MasterMindBoard()
        # >>> test = 1234
        # >>> a.guess(test)
        # >>> a.display_clue()
        # "****"
        # >>> a.done()
        Process finished with exit code 0
        """
        if self.clue == "****":
            print(f"You solve it after {self.num_guesses} rounds")
            return True
        else:
            return False


# new_game = MasterMindBoard()
# while True:
#     input_guess = input("What is your guess?: ")
#     print('Your guess is', input_guess)
#     MasterMindBoard.guess(input_guess)
#     MasterMindBoard.display_clue()
#     if MasterMindBoard.done():
#         break
