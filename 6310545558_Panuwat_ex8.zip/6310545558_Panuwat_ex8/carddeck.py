class CardDeck:
    """This class describes a deck of 52 cards with 4 suits and 13 ranks\n"""

    def __init__(self):
        SUITS = ['\u2663', '\u2666', '\u2665', '\u2660']
        RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack',
                 'Queen', 'King', 'Ace']
        deck = []
        for rank in RANKS:
            for suit in SUITS:
                card = rank + ' ' + suit
                deck += [card]
        self.card_deck = deck
        self.num_card_draw = 0

    def __str__(self):
        """Returns a string representation of this deck class"""
        card_str = ""
        card_str += "| "
        for card in self.card_deck:
            card_str += card + " | "
        return card_str
        # t_list = []
        # for i in self.card_deck:
        #     t_list.append(i)
        #
        # return t_list

    # methods for performing operations on a deck of cards to follow
    def shuffle(self):
        """Shuffle cards in the deck. Returns a list of the deck."""
        import random

        n = len(self.card_deck)
        for i in range(n):
            r = random.randrange(i, n)
            temp = self.card_deck[r]
            self.card_deck[r] = self.card_deck[i]
            self.card_deck[i] = temp
        return self.card_deck

    def draw_card(self, count):
        """Draw card(s) from the deck. Returns a list of drawn cards."""
        # test_num = len(self.card_deck) - 1
        drawn_cards = []
        # drawn_cards.append(self.card_deck[test_num])
        for i in range(self.num_card_draw, self.num_card_draw + count):
            drawn_cards.append(self.card_deck[i])
        self.num_card_draw += count
        for i in drawn_cards:
            self.card_deck.remove(i)
        return drawn_cards



# a = CardDeck()
# print(a)
# a.shuffle()
# print(a)
# b = a.draw_card(1)
# print(b)
# print(a)

# a = CardDeck()
# b = CardDeck.shuffle(a)
# print(b)
# b = CardDeck.draw_card(2)
#
# print(b)