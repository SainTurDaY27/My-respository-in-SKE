from carddeck import *


class BlackJack:
    """This class describes the game of Blackjack itself\n"""

    def __init__(self):
        deck = CardDeck()
        deck.shuffle()
        self.bj_deck = deck
        self.player_hand = []
        self.computer_hand = []
        self.player_hand_value = 0  # can have multiple values when hand involves Aces
        self.computer_hand_value = 0  # can have multiple values when hand involves Aces
        self.player_hand_status = ...  # [stay or dead or can_stay or must_draw_more]
        self.computer_hand_status = ...  # [stay or dead or can_stay or must_draw_more]

    def start(self):
        """This method starts the game by drawing from the card deck (represented by
        self.bj_deck) two cards for player and two cards for computer; then it proceed to update all
        the values and statuses for both hands
        """
        self.player_hand = [i for i in self.bj_deck.draw_card(2)]
        self.computer_hand = [i for i in self.bj_deck.draw_card(2)]
        print("Let's play Blackjack!")
        # print(self.player_hand)
        print(self.display_player_hand(2))
        print(self.display_computer_hand(1))

    def manage_value(self, cards):
        """This method is about to translate the type of card to value of that card in different situation in
        BlackJack
        """
        turn = 0
        turn2 = 0
        for card in cards:
            if "Jack" in card:
                turn += 10
                turn2 += 10
            elif "Queen" in card:
                turn += 10
                turn2 += 10
            elif "King" in card:
                turn += 10
                turn2 += 10
            elif "10" in card:
                turn += 10
                turn2 += 10
            elif "Ace" in card:
                turn += 11
                turn2 += 1
            elif "1" in card:
                turn += 1
                turn2 += 1
            elif "2" in card:
                turn += 2
                turn2 += 2
            elif "3" in card:
                turn += 3
                turn2 += 3
            elif "4" in card:
                turn += 4
                turn2 += 4
            elif "5" in card:
                turn += 5
                turn2 += 5
            elif "6" in card:
                turn += 6
                turn2 += 6
            elif "7" in card:
                turn += 7
                turn2 += 7
            elif "8" in card:
                turn += 8
                turn2 += 8
            elif "9" in card:
                turn += 9
                turn2 += 9

        if turn <= 21:
            return turn
        else:
            return turn2

    def manage_status(self):
        """This method is about to manage the player and computer status.
        """
        self.player_hand_value = self.manage_value(self.player_hand)
        if self.player_hand_value >= 16:
            self.player_hand_status = "can_stay"

        self.computer_hand_value = self.manage_value(self.computer_hand)
        if self.computer_hand_value >= 16:
            self.computer_hand_status = "can_stay"

    def adjust_player_hand(self):
        """This method draws an additional card and reevalute the value and status of the
        player hand
        """
        test = ""
        self.manage_status()
        self.display_player_hand(len(self.player_hand))
        if self.player_hand_status != "can_stay":
            card = self.bj_deck.draw_card(1)
            for i in card:
                test += i
            self.player_hand.append(test)

        self.player_hand_value += self.manage_value(self.player_hand)

    def adjust_computer_hand(self):
        """This method draws an additional card and reevalute the value and status of the computer hand
        """
        test = ""
        self.manage_status()
        if self.computer_hand_status != "can_stay":
            card = self.bj_deck.draw_card(1)
            for i in card:
                test += i
            self.computer_hand.append(test)
            # print(self.computer_hand)
        self.computer_hand_value += self.manage_value(self.computer_hand)
        # print(self.computer_hand_value)

    def display_player_hand(self, num):
        """This method reveals the player hand
        """
        ans = ""
        for i in range(num):
            ans += str(self.player_hand[i])
            ans += " "
        final_ans = "Your hand: " + ans
        return final_ans

    def display_computer_hand(self, num):
        """This method reveals the computer hand
        """
        ans = ""
        for i in range(num):
            ans += str(self.computer_hand[i])
            ans += " "
        final_ans = "Computer hand: " + ans
        return final_ans

    def decision(self):
        """This method makes a decision if the player wins, looses, or ties with the computer
        """
        if self.computer_hand_value < self.player_hand_value <= 21:
            print("Player wins")
        elif self.player_hand_value < self.computer_hand_value <= 21:
            print("Computer wins")
        else:
            print("Both ties")
        return True


# new_BJ = BlackJack()
# new_BJ.start()
# # player plays
# while new_BJ.player_hand_status != 'can_stay':
#     new_BJ.manage_status()
#     new_BJ.adjust_player_hand()
#     new_BJ.display_player_hand(len(new_BJ.player_hand))
# while new_BJ.player_hand_status == 'can_stay':
#     new_BJ.manage_status()
#     to_stay_or_not = input("stay or not: ")
#     if to_stay_or_not == "no":
#         new_BJ.adjust_player_hand()
#         new_BJ.display_player_hand(len(new_BJ.player_hand))
#     else:
#         new_BJ.player_hand_status = "stay"
#
# # computer plays
# while new_BJ.computer_hand_status != 'can_stay':
#     # new_BJ.manage_status()
#     new_BJ.adjust_computer_hand()
#     new_BJ.display_computer_hand(len(new_BJ.computer_hand))
# while new_BJ.computer_hand_value < new_BJ.player_hand_value and new_BJ.computer_hand_status == 'can_stay':
#     new_BJ.manage_status()
#     new_BJ.adjust_computer_hand()
#     new_BJ.display_computer_hand(len(new_BJ.computer_hand))
#
# new_BJ.decision()
