# Problem1
FEET_IN_MILE = 5280
miles = 13
feet = FEET_IN_MILE * miles
print(feet)

# Problem2
hours = 7
minutes = 21
seconds = 37
hours_to_second = hours*60*60
minutes_to_second = minutes*60
total_second = seconds+hours_to_second+minutes_to_second
print(f"Total number of seconds is {total_second}")

# Problem3
width = 4
height = 7
perimeter_of_retangle = (2*width) + (2*height)
print(f"the length of the perimeter of a rectangle is {perimeter_of_retangle}.")

# Problem4
pi = 3.14
radius = 8
area = pi*(radius**2)
print(f"Area of the circle is {area:.3f}")

# Problem5
present_value = 1000
annual_rate = 7
years = 10
future_value = present_value*(1+0.01*annual_rate)*years
print(f"The future value is {future_value:.2f}")

# Problem6
from math import sqrt
x0, y0 = 2, 2
x1, y1 = 5, 6
distance_between_two_point = sqrt(((x0-x1)**2)+((y0-y1)**2))
print(f"The distance between the points (2,2) and (5,6) is {distance_between_two_point}")

# Problem7
from math import sqrt
X0, Y0 = 1, 1
X1, Y1 = 4, 1
X2, Y2 = 4, 5
side_a = sqrt(((X0-X1)**2)+((Y0-Y1)**2))
side_b = sqrt(((X1-X2)**2)+((Y1-Y2)**2))
side_c = sqrt(((X0-X2)**2)+((Y0-Y2)**2))
s = 0.5*(side_a+side_b+side_c)
triangle_area = sqrt(s*(s-side_a)*(s-side_b)*(s-side_c))
print(f"the area of a triangle whose vertices are(1, 1), (4, 1), and (4, 5) is {triangle_area}")

# Problem8
input_cup = int(input("Write how many cups of coffee you will need:"))
print(f"For {input_cup} of coffee you will need:")
water = input_cup*200
milk = input_cup*50
coffee_beans = input_cup*15
print(f"{water} ml of water")
print(f"{milk} ml of milk")
print(f"{coffee_beans} g of coffee beans")
