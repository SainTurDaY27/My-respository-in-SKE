# Level 1

'''
Implement the following function that returns the list of indices of a specified character,c, in an input string, s.

def char_index_list(s, c):

Include Google’s style docstring and put at least six normal test cases in the doctest. In addition, your code needs to raise appropriate exceptions and  exception test cases needs to be included in the doctest as well.

Examples:
print(char_index_list("aabaabaacca", 'a')) # [0, 1, 3, 4, 6, 7, 10]
print(char_index_list("aabaabaacca", 'b')) # [2, 5]
print(char_index_list("aabaabaacca", 'c')) # [8, 9]
print(char_index_list("aabaabaacca", 'e')) # []

'''

def char_index_list(s, c):
    """
    Implement the following function that returns the list of indices of a specified character,c, in an input string, s.

    Args :
        s, c (string) : input two string

    Returns :
        (list) :  the list of indices of a specified character,c, in an input string, s

    Raises :
        TypeError: If s or c is not a string

    Examples:
    >>> char_index_list("aabaabaacca", 'a')
    [0, 1, 3, 4, 6, 7, 10]
    >>> char_index_list("aabaabaacca", 'b')
    [2, 5]
    >>> char_index_list("aabaabaacca", 'c')
    [8, 9]
    >>> char_index_list("aabaabaacca", 'e')
    []
    >>> char_index_list("pypppypyppy", 'p')
    [0, 2, 3, 4, 6, 8, 9]
    >>> char_index_list("pypppypyppy", 27)
    Traceback (most recent call last):
        ...
    TypeError: Input is not string

    """
    if isinstance(s,str) or isinstance(c,str) == False:
        raise TypeError("Input is not a string")


    f_list = []
    ans_list = []
    for i in range(len(s)):
        f_list.append(s[i])
    for i in range(len(s)):
        if c in f_list[i]:
            ans_list.append(i)
        else:
            pass
    return ans_list




