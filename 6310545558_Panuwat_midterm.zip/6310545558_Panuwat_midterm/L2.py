# Level 2

'''
Implement the following function that returns a new string that replaces the first occurrence of pattern1 in the input string, s, with pattern2.

def replace_first_occurrence(s, pattern1, pattern2):

Examples:
print(replace_first_occurrence('good bad good bad', 'bad', 'good')) # good good good bad
print(replace_first_occurrence('good good good good', 'bad', 'good')) # good good good good
print(replace_first_occurrence('aaaaa aaa', 'aa', 'zxz')) # zxzaaa aaa
print(replace_first_occurrence('bbab baa', 'aa', 'zxz')) # bbab bzxz
print(replace_first_occurrence('bbaaabbaaaabcccaa', 'aa', 'zxz')) # bzxzabbaaaabcccaa

You do not need to include docstring and doctest for this problem, but your code must pass all the test cases above. 
'''

def replace_first_occurrence(s, pattern1, pattern2):
    a = s.split()

    for i in range(len(a)):
        if pattern1 in a:
            a[i] = pattern2
            pass
        else:
            pass
    return a

    # your code goes here; remove the keyword pass below once completed.

print(replace_first_occurrence('good bad good bad', 'bad', 'good'))
print(replace_first_occurrence('good good good good', 'bad', 'good'))
print(replace_first_occurrence('aaaaa aaa', 'aa', 'zxz'))
print(replace_first_occurrence('bbab baa', 'aa', 'zxz'))
print(replace_first_occurrence('bbaaabbaaaabcccaa', 'aa', 'zxz'))
print()

'''
Implement the following function that creates a new list that removes adjacent duplicates from the input integer list, int_list.

def remove_adjacent_duplicates(int_list):

Examples:
print(remove_adjacent_duplicates([1, 1, 1, 1, 2, 5, 5, 5, 3])) # [1, 2, 5, 3]
print(remove_adjacent_duplicates([1, 1, 5, 5, 10, 8, 7, 5, 5, 5, 12, 4, 12, 12])) # [1, 5, 10, 8, 7, 5, 12, 4, 12]
print(remove_adjacent_duplicates([12, 12, 12])) # [12]
print(remove_adjacent_duplicates([1, 2, 3])) # [1, 2, 3]
print(remove_adjacent_duplicates([])) # []

You do not need to include docstring and doctest for this problem, but your code must pass all the test cases above.
'''
def remove_adjacent_duplicates(int_list):

    # your code goes here; remove the keyword pass below once completed.
    f_list = []
    for i in range(len(int_list)):
        if int_list[i] not in f_list:
            f_list.append(int_list[i])
        else:
            pass

    return f_list



print(remove_adjacent_duplicates([1, 1, 5, 5, 10, 8, 7, 5, 5, 5, 12, 4, 12, 12]))
print(remove_adjacent_duplicates([1, 1, 1, 1, 2, 5, 5, 5, 3]))
print(remove_adjacent_duplicates([12, 12, 12]))
print(remove_adjacent_duplicates([1, 2, 3]))
print(remove_adjacent_duplicates([]))
print()
