# Level 3

'''
Implement the following function that returns a list of integer lists. Each integer list element groups the same element(s) from the interger input list, int_list, together.

def group_elements(int_list):


Examples:
print(group_elements([1, 3, 3, 4, 2, 5, 8, 5, 6, 7])) # [[1], [3, 3], [4], [2], [5, 5], [8], [6], [7]]
print(group_elements([3, 3, 3, 3])) # [[3, 3, 3, 3]]
print(group_elements([3, 3, 1, 3, 3, 1])) # [[3, 3, 3, 3], [1, 1]]
print(group_elements([5, 3, 1, 2, 4, 10])) # [[5], [3], [1], [2], [4], [10]]

You do not need to include docstring and doctest for this problem, but your code must pass all the test cases above. Note that the ordering of the groups can be different.
'''

def group_elements(int_list):
#     f_list = []
#     for i in range(len(int_list)):
#         f_list.append(int_list[i])
#         print(f_list)
#     for i in range(len(f_list)):
    f_list = []
    s_list = []
    t_list = []
    fo_list = []
    final_list = []
    f_list.append(int_list[0])
    for i in range(len(int_list)):
        if int_list[i] == f_list[0]:
            if int_list[i] in s_list[0]:
                if int_list[i] in t_list[0]:
                    if int_list[i] in fo_list[0]:
                        pass
                    else:
                        fo_list.append(int_list[i])
                else:
                    t_list.append(int_list[i])
            else:
                s_list.append(int_list[i])
        else:
            f_list.append(int_list[i])
    final_list.append(f_list)
    final_list.append(s_list)
    final_list.append(t_list)
    final_list.append(fo_list)
    return final_list
    # your code goes here; remove the keyword pass below once completed.

print(group_elements([1, 3, 3, 4, 2, 5, 8, 5, 6, 7])) # [[1], [3, 3], [4], [2], [5, 5], [8], [6], [7]]
print(group_elements([3, 3, 3, 3])) # [[3, 3, 3, 3]]
print(group_elements([3, 3, 1, 3, 3, 1])) # [[3, 3, 3, 3], [1, 1]]
print(group_elements([5, 3, 1, 2, 4, 10])) # [[5], [3], [1], [2], [4], [10]]
