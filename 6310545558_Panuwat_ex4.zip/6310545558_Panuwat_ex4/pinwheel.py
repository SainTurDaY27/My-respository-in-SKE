import random
import turtle

turtle.speed(10)
turtle.setheading(0)


def pinwheel(num_branch, size, backup):
    for i in range(num_branch):
        turtle.pendown()
        turtle.forward(size)
        turtle.backward(backup)
        turtle.left(360 / num_branch)
        turtle.penup()


turtle.penup()
for i in range(30):
    clr_list = random.choice(["red", "blue", "gold", "brown", "violet", "pink", "orange", "yellow", "green"])
    turtle.pencolor(clr_list)
    shapesize = random.randint(25, 100)
    side = random.randint(5, 20)
    backup = random.randint(25, 150)
    turtle.goto(random.randint(-300, 300), random.randint(-300, 300))
    turtle.pensize(random.randint(5, 30))
    pinwheel(side, shapesize, backup)


turtle.done()