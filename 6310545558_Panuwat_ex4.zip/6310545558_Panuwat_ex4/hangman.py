import random
import sys

word_list = ["python", "java", "kotlin", "javascript"]
random_list = random.choice(word_list)
word_sep = list(random_list)
chance = 0

print("H A N G M A N")
f_list = []
for i in range(len(random_list)):
    f_list.append("-")


while chance != 8:
    for i in range(len(word_sep)):
        print(f_list[i], end='')
    print()
    if f_list == word_sep:
        print("You guessed the word!")
        print("You survived!")
        sys.exit()
    letter_input = str(input("Input a letter: "))
    if letter_input in word_sep:
        if letter_input in f_list:
            print("No improvements")
            chance += 1
        else:
            if random_list == "python":
                if letter_input == "p":
                    f_list[0] = "p"
                elif letter_input == "y":
                    f_list[1] = "y"
                elif letter_input == "t":
                    f_list[2] = "t"
                elif letter_input == "h":
                    f_list[3] = "h"
                elif letter_input == "o":
                    f_list[4] = "o"
                elif letter_input == "n":
                    f_list[5] = "n"
            elif random_list == "java":
                if letter_input == "j":
                    f_list[0] = "j"
                elif letter_input == "a":
                    f_list[1] = "a"
                    f_list[3] = "a"
                elif letter_input == "v":
                    f_list[2] = "v"
            elif random_list == "kotlin":
                if letter_input == "k":
                    f_list[0] = "k"
                elif letter_input == "o":
                    f_list[1] = "o"
                elif letter_input == "t":
                    f_list[2] = "t"
                elif letter_input == "l":
                    f_list[3] = "l"
                elif letter_input == "i":
                    f_list[4] = "i"
                elif letter_input == "n":
                    f_list[5] = "n"
            elif random_list == "javascript":
                if letter_input == "j":
                    f_list[0] = "j"
                elif letter_input == "a":
                    f_list[1] = "a"
                    f_list[3] = "a"
                elif letter_input == "v":
                    f_list[2] = "v"
                elif letter_input == "s":
                    f_list[4] = "s"
                elif letter_input == "c":
                    f_list[5] = "c"
                elif letter_input == "r":
                    f_list[6] = "r"
                elif letter_input == "i":
                    f_list[7] = "i"
                elif letter_input == "p":
                    f_list[8] = "p"
                elif letter_input == "t":
                    f_list[9] = "t"

    elif letter_input not in word_sep:
        print("No such letter in the word")
        chance += 1
print("You are hanged!")
