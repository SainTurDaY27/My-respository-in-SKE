# 1_coffee_machine
water = 400
milk = 540
coffee_bean = 120
cup = 9
money = 550


def choose_mode():
    mode_input = str(input("Write action (buy, fill, take, remaining, exit): "))
    return mode_input


def buy_mode():
    global water, coffee_bean, money, cup, milk
    coffee_input = str(input("What do you want to buy? 1 - espresso, 2 - latte, 3 - cappuccino, back - to main menu: "))
    if coffee_input == "1":
        if water >= 250 and coffee_bean >= 16 and cup >= 1:
            print("I have enough resources, making you a coffee!")
            water -= 250
            coffee_bean -= 16
            money += 4
            cup -= 1
        else:
            if water < 350:
                print("Sorry, not enough water!")
            elif coffee_bean < 20:
                print("Sorry, not enough coffee beans!")
            elif milk < 75:
                print("Sorry, not enough milk!")
            elif cup < 1:
                print("Sorry, not enough cup!")
    elif coffee_input == "2":
        if water >= 350 and coffee_bean >= 20 and milk >= 75 and cup >= 1:
            print("I have enough resources, making you a coffee!")
            water -= 350
            coffee_bean -= 20
            money += 7
            cup -= 1
            milk -= 75
        else:
            if water < 350:
                print("Sorry, not enough water!")
            elif coffee_bean < 20:
                print("Sorry, not enough coffee beans!")
            elif milk < 75:
                print("Sorry, not enough milk!")
            elif cup < 1:
                print("Sorry, not enough cup!")
    elif coffee_input == "3":
        if water >= 200 and coffee_bean >= 12 and milk >= 100 and cup >= 1:
            print("I have enough resources, making you a coffee!")
            water -= 200
            coffee_bean -= 12
            money += 6
            cup -= 1
            milk -= 100
        else:
            if water < 200:
                print("Sorry, not enough water!")
            elif coffee_bean < 12:
                print("Sorry, not enough coffee beans!")
            elif milk < 100:
                print("Sorry, not enough milk!")
            elif cup < 1:
                print("Sorry, not enough cup!")
    elif coffee_input == "back":
        pass


def fill_mode():
    global water, coffee_bean, money, cup, milk
    add_water = int(input("Write how many ml of water do you want to add: "))
    add_milk = int(input("Write how many ml of milk do you want to add: "))
    add_coffee_bean = int(input("Write how many grams of coffee beans do you want to add: "))
    add_cup = int(input("Write how disposable cups of coffee do you want to add: "))
    water += add_water
    milk += add_milk
    coffee_bean += add_coffee_bean
    cup += add_cup


def take_mode():
    global money
    print(f"I gave you ${money}")
    money = 0


def remaining_mode():
    global water, coffee_bean, money, cup, milk
    print(f"The coffee machine has: ")
    print(f"{water} of water")
    print(f"{milk} of milk")
    print(f"{coffee_bean} of coffee beans")
    print(f"{cup} of disposable cups")
    print(f"${money} of money")


while True:
    mode_input = choose_mode()
    if mode_input == "buy":
        buy_mode()
    elif mode_input == "fill":
        fill_mode()
    elif mode_input == "take":
        take_mode()
    elif mode_input == "remaining":
        remaining_mode()
    elif mode_input == "exit":
        break
