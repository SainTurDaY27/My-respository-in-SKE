# 1_coffee_machine


def buy_mode():
      coffee_input = input("What do you want to buy? 1 - espresso, 2 - latte, 3 - cappuccino")
      return coffee_input


water = 400
milk = 540
coffee_bean = 120
cup = 9
money = 550

print("The coffee machine has: ")
print("400 of water")
print("540 of milk")
print("120 of coffee beans")
print("9 of disposable cups")
print("550 of money")
print("")
mode_input = input("Write action (buy, fill, take): ")
if mode_input == "buy":
      coffee_input = float(input("What do you want to buy? 1 - espresso, 2 - latte, 3 - cappuccino: "))
      if coffee_input == 1:
            water_f = water - 250
            coffee_bean_f = coffee_bean - 16
            money_f = money + 4
            cup_f = cup - 1
            print("The coffee machine has: ")
            print(f"{water} of water")
            print(f"{milk} of milk")
            print(f"{coffee_bean} of coffee beans")
            print(f"{cup} of disposable cups")
            print(f"{money} of money")
      elif coffee_input == 2:
            water_f = water - 350
            milk_f = milk - 75
            coffee_bean_f = coffee_bean - 20
            money_f = money + 7
            cup_f = cup - 1
            print("The coffee machine has: ")
            print(f"{water_f} of water")
            print(f"{milk_f} of milk")
            print(f"{coffee_bean_f} of coffee beans")
            print(f"{cup_f} of disposable cups")
            print(f"{money_f} of money")
      elif coffee_input == 3:
            water_f = water - 200
            milk_f = milk - 100
            coffee_bean_f = coffee_bean - 12
            money_f = money + 6
            cup_f = cup - 1
            print("The coffee machine has: ")
            print(f"{water_f} of water")
            print(f"{milk_f} of milk")
            print(f"{coffee_bean_f} of coffee beans")
            print(f"{cup_f} of disposable cups")
            print(f"{money_f} of money")
elif mode_input == "fill":
      add_water = int(input("Write how many ml of water do you want to add: "))
      add_milk = int(input("Write how many ml of milk do you want to add: "))
      add_coffee_bean = int(input("Write how many grams of coffee beans do you want to add: "))
      add_cup = int(input("Write how disposable cups of coffee do you want to add: "))
      print("The coffee machine has: ")
      print(f"{400 + add_water} of water")
      print(f"{540 + add_milk} of milk")
      print(f"{120 + add_coffee_bean} of coffee beans")
      print(f"{9 + add_cup} of disposable cups")
      print(f"550 of money")
elif mode_input == "take":
      print("I gave you $550")
      print("")
      print("The coffee machine has: ")
      print("400 of water")
      print("540 of milk")
      print("120 of coffee beans")
      print("9 of disposable cups")
      print("550 of money")
