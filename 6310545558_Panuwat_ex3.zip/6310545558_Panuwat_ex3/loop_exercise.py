
def fib(n):
    round = int()
    n1, n2 = 0, 1
    while round <= n:
        print(n2, end=" ")
        n_final = n1 + n2
        n1 = n2
        n2 = n_final
        round += 1

print("fib(n) result:")
n = 0
while n < 10:
    fib(n)
    print("")
    n += 1

def diamond(n):
    """This function prints a diamond shape of size n as shown in loop_exercise_result.txt
    """
    amount = 0
    round = 0
    space = " "
    while round < n:
        amount = amount + 1
        asterisk = "*" * (amount * 2)
        number = ((n * 2) - len(asterisk)) / 2
        print(f" {space * int(number)}{asterisk}")
        round = round + 1
    while round > 0:
        asterisk = "*" * (amount * 2)
        number = ((n * 2) - len(asterisk)) / 2
        print(f" {space * int(number)}{asterisk}")
        round = round - 1
        amount = amount - 1

print("diamond(n) result:")
for i in range(0, 8):
    diamond(i)
    print("")

def hailstone(n):
    """This function prints a hailstone sequence whose details can be found in this link:
        http://mathworld.wolfram.com/CollatzProblem.html
    """
    num = n
    if num == 1:
        print(num, end=" ")
    else:
        print(num, end="  ")
        while num != 1:
            if num % 2 ==0:
                num = num / 2
                if num == 1:
                    print(int(num), end=" ")
                else:
                    print(int(num), end="  ")
            elif num % 2 != 0:
                num = (num * 3) + 1
                if num == 1:
                    print(int(num), end=" ")
                else:
                    print(int(num), end="  ")



print("hailstone(n) result:")
for i in range(1, 8):
    hailstone(i)
    print("")

def arith_sum(n):
    """This function prints the arithmetic sequence starting from 1 to nth together with its sum
    """
    num = 1
    total = 0
    while num <= (n-1):
        print(f"{num} +", end=" ")
        num += 1
    total = int((n/2)*(n+1))
    print(f"{n} = {total}", end=" ")

print("arith_sum(n) result:")
for i in range(1, 10):
    arith_sum(i)
    print("")  

